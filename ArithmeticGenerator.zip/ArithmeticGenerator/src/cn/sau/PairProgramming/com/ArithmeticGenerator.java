package cn.sau.PairProgramming.com;


import windowsDesign.Interface;
import windowsDesign.SubstanceTools;


public class ArithmeticGenerator {

	public static void main(String[] args){
		try {
			SubstanceTools.useSkin();//使用皮肤  
			SubstanceTools.useTheme();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//使用主题
		new Interface();
	}
}
