package cn.sau.PairProgramming.com;

public class GetOperator {
	private boolean plus,sub,mult,div;
	private int size;
	public GetOperator(){ ///如果用户要求默认只生成 加法运算
		this.plus = true;
		this.sub = false;
		this.mult = false;
		this.div = false;
	}
	public GetOperator(boolean plus,boolean sub,boolean mult,boolean div){
		this.plus = plus;
		this.sub = sub;
		this.mult = mult;
		this.div = div;
	}
	
	public String GetRuler(){
		String str = "";
		if (plus == true) str += "+";
		if (sub == true) str += "-";
		if (mult == true) str += "*";
		if (div == true) str += "/";
		return str;
	}
	
	public int getSize(){ ///返回用户点击了多少个按钮
		size = GetRuler().length();
		return size;
	}
	
	//为了安全性只允许用户访问属性，而不能进行修改
	public boolean isPlus() {
		return plus;
	}
	
	public boolean isSub() {
		return sub;
	}
	
	public boolean isMult() {
		return mult;
	}
	
	public boolean isDiv() {
		return div;
	}
	
}
