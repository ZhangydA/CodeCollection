package cn.sau.PairProgramming.com;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * 小学的四则运算的生成器,100内的加减乘除
 * @author ZhangyiA
 *
 */

public class QusetionGenerator {
	
	private int maxn,mins,quseNum; 
	//整数， 小数，多项式
	private boolean IntNum,DouNum,Polynomial;
	private String str = "";
	private ArrayList<String> qusetion = new ArrayList<String>();
	private ArrayList<String> answer = new ArrayList<String>();
	///测试只生成加法
	//如果没有给最大值和最小值的话默认是0~100以内,数量为20道题,整数的运算，且无多项式
	public QusetionGenerator(){
		this.maxn = 100;
		this.mins = 0;
		this.quseNum = 20;
		this.str = "+";
		this.IntNum = true;
		this.DouNum = false;
		this.Polynomial = false;
	}
	
	public QusetionGenerator(GetOperator GO){
		this();
		this.str = GO.GetRuler();
	}
	
	public QusetionGenerator(boolean IntNum,boolean DouNum,boolean Polynomial){
		this.IntNum = IntNum;
		this.DouNum = DouNum;
		this.Polynomial = Polynomial;
	}
	
	public QusetionGenerator(int maxn,int mins,int quseNum,
			boolean IntNum,boolean DouNum,boolean Polynomial,GetOperator GO){
		this.maxn = maxn;
		this.mins = mins;
		this.quseNum = quseNum;
		this.str = GO.GetRuler(); //得到符号串 Polynomial(多项式)
		this.IntNum = IntNum;
		this.DouNum = DouNum;
		this.Polynomial = Polynomial;
	}
	
	//启动生成器
	public boolean startGenerator(){
		//不是多项式，且
		if (IntNum == true && DouNum == true){
			return false;
		} else if(IntNum == true && Polynomial == false){
			getIntegerQuestion();
			return true;
		} else if (IntNum == true && Polynomial == true){
			getIntegerPolynomialQusetion();
			return true;
		} else if (DouNum == true && Polynomial == false){
			getDoubleQuestion();
			return true;
		} else if (DouNum == true && Polynomial == true){
			getDoublePolynomialQusetion();
			return true;
		} else return false;
	}
	
	public boolean getIntegerQuestion(){
		RandomNumber rand = new RandomNumber(maxn,mins);
		String temp = "";
		int numa = 0,numb = 0,oper = 0;
		for (int i = 0;i < quseNum;i ++){
			numa = rand.Random_Integer();
			numb = rand.Random_Integer();
			oper = rand.Random_Integer(str.length(),0);
			temp = numa + " " + str.charAt(oper) + " " + numb;
			qusetion.add(temp);
			getAnswer(temp.replace(" ", ""),temp);
		}
		return true;
	}
	
	public boolean getDoubleQuestion(){
		RandomNumber rand = new RandomNumber(maxn,mins);
		String temp = "";
		double numa = 0,numb = 0;
		int oper = 0;
		for (int i = 0;i < quseNum;i ++){
			numa = rand.Random_Double();
			numb = rand.Random_Double();
			oper = rand.Random_Integer(str.length(),0);
			temp = numa + " " + str.charAt(oper) + " " + numb;
			qusetion.add(temp);
			getAnswer(temp.replace(" ", ""),temp);
		}
		return true;
	}
	
	public Map<String,Integer> getPriority(){
		Map<String,Integer> mp = new HashMap<String,Integer>();
		mp.put("+", 0);
		mp.put("-", 0);
		mp.put("*", 1);
		mp.put("/", 1);
		return mp;
	}
	//转进多项式的三个数，以及符号
	public String getContians(String numa,String numb,String numc,String oper1,String oper2){
		String temp = "";
		//获取优先级
		RandomNumber rand = new RandomNumber();
		Map<String,Integer> mp = getPriority();
		if (mp.get(oper1) < mp.get(oper2)){
			temp = "( " + numa + " " + oper1 + " " + numb + " )" + " " + oper2 + " " + numc;
		} else if(mp.get(oper1) > mp.get(oper2)){
			int flagBracket = rand.Random_Integer(2,0);
			if (flagBracket == 0){
				temp = numa + " " + oper1 + " " + numb + " " + oper2 + " " + numc;
			} else {
				temp = numa + " " + oper1 + " " + "( " +numb + " " + oper2 + " " + numc + " )";
			}
		} else {
			//是否还有括号标志 flagBracket，0 代表没有，1 代表有，阔好的位置 flagOpersition，0代表第一个位置，1代表第二种情况
			int flagBracket = rand.Random_Integer(2,0);
			if (flagBracket == 0){
				temp = numa + " " + oper1 + " " + numb + " " + oper2 + " " + numc;
			} else {
				int flagOpersition = rand.Random_Integer(2,0);
				if (flagOpersition == 0){
					temp = "( " + numa + " " + oper1 + " " + numb + " )" + " " + oper2 + " " + numc;
				} else {
					temp = numa + " " + oper1 + " " + "( " +numb + " " + oper2 + " " + numc + " )";
				}
			}
		}
		return temp;
	}
	
	public boolean getIntegerPolynomialQusetion(){
		RandomNumber rand = new RandomNumber(maxn,mins);
		int oper1 = 0,oper2 = 0,numa = 0,numb = 0,numc = 0;
		for (int i = 0;i < quseNum;i ++){
			//生成两个操作符
			oper1 = rand.Random_Integer(str.length(),0);
			oper2 = rand.Random_Integer(str.length(),0);
			//生成三个数
			numa = rand.Random_Integer();
			numb = rand.Random_Integer();
			numc = rand.Random_Integer();
			//将字符的运算符，转换为字符串
			String a = str.charAt(oper1)+"";
			String b = str.charAt(oper2)+"";
			String temp = getContians(numa+"",numb+"",numc+"",a,b);
			qusetion.add(temp);
			getAnswer(temp.replace(" ", ""),temp);
		}
		return true;
	}
	
	public boolean getDoublePolynomialQusetion(){
		RandomNumber rand = new RandomNumber(maxn,mins);
		int oper1 = 0,oper2 = 0;
		double numa = 0,numb = 0,numc = 0;
		for (int i = 0;i < quseNum;i ++){
			//生成两个操作符
			oper1 = rand.Random_Integer(str.length(),0);
			oper2 = rand.Random_Integer(str.length(),0);
			//生成三个数
			numa = rand.Random_Double();
			numb = rand.Random_Double();
			numc = rand.Random_Double();
			//将字符的运算符，转换为字符串
			String a = str.charAt(oper1)+"";
			String b = str.charAt(oper2)+"";
			String temp = getContians(numa+"",numb+"",numc+"",a,b);
			qusetion.add(temp);
			getAnswer(temp.replace(" ", ""),temp);
		}
		return true;
	}
	
	public String printQusetion(){
		String temp = "";
		for (int i = 0;i < qusetion.size();i ++){
			temp += qusetion.get(i) + " = \n";
			//System.out.println(qusetion.get(i) + " = ");
		}
		return temp;
	}
	
	public void getAnswer(String expression,String str){
		double result = Calculator.conversion(expression);
		if (result - (int)result == 0.0)
			answer.add(str + " = " + (int)result);
		else{
			BigDecimal f1 = new BigDecimal(result);
			result = f1.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue();
			answer.add(str + " = " + result);
		}
	}
	
	public String printAnswer(){
		String temp = "";
		for (int i = 0;i < answer.size();i ++){
			temp += answer.get(i) + "\n";
		}
		return temp;
	}
	
	public ArrayList<String> getAnswer() {
		return answer;
	}

	public int getMaxn() {
		return maxn;
	}
	
	public void setMaxn(int maxn) {
		this.maxn = maxn;
	}
	
	public int getMins() {
		return mins;
	}
	
	public void setMins(int mins) {
		this.mins = mins;
	}

	public int getQuseNum() {
		return quseNum;
	}

	public void setQuseNum(int quseNum) {
		this.quseNum = quseNum;
	}

	public ArrayList<String> getQustion() {
		return qusetion;
	}

	public String getStr() {
		return str;
	}
	
}
