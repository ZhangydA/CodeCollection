package cn.sau.PairProgramming.com;

import java.math.BigDecimal;
import java.util.Random;

public class RandomNumber {
	
	private int maxn,mins;
	
	public RandomNumber(){
		
	}
	
	public RandomNumber(int maxn,int mins){
		this.maxn = maxn;
		this.mins = mins;
	}

	public int Random_Integer(){
		int num = 0;
		Random rand = new Random();
		num = rand.nextInt(maxn - mins) + mins;
		return num;
	}
	
	public int Random_Integer(int maxn,int mins){
		int num = 0;
		Random rand = new Random();
		num = rand.nextInt(maxn - mins) + mins;
		return num;
	}
	
	public double Random_Double(){
		double num = 0;
		num = Math.random() * (maxn - mins) + mins;
		BigDecimal f1 = new BigDecimal(num);
		num = f1.setScale(1,BigDecimal.ROUND_HALF_UP).doubleValue();
		return num;
	}
	
	public int getMaxn() {
		return maxn;
	}

	public void setMaxn(int maxn) {
		this.maxn = maxn;
	}

	public int getMins() {
		return mins;
	}

	public void setMins(int mins) {
		this.mins = mins;
	}
	
}
