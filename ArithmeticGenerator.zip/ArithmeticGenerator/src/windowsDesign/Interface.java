package windowsDesign;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import cn.sau.PairProgramming.com.GetOperator;
import cn.sau.PairProgramming.com.QusetionGenerator;


public class Interface extends JFrame
{
	private JPanel contentPane;
    private JTextField textNum;
    private JTextField textMaxn;
    private JTextField textMins;
    int quseNum,Maxn,Mins;
    QusetionGenerator QG;
	public Interface()
	{
		setTitle("小学四则运算自动生成程序");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.pack();
		setBounds(100, 100, 500, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel title = new JLabel("小学四则运算自动生成程序");
		title.setForeground(Color.BLACK);
		title.setFont(new Font("幼圆", Font.BOLD, 20));
		title.setBounds(120, 10, 300, 40);
		contentPane.add(title);
		
		JLabel lblNewLabel = new JLabel("题目数量：");
		lblNewLabel.setBounds(10, 63, 75, 20);
		contentPane.add(lblNewLabel);
		
		textNum = new JTextField();
		textNum.setBounds(82, 60, 66, 21);
		contentPane.add(textNum);
		textNum.setColumns(10);
		
		JLabel label = new JLabel("最大值：");
		label.setBounds(182, 63, 85, 15);
		contentPane.add(label);
		
		textMaxn = new JTextField();
		textMaxn.setBounds(239, 60, 66, 21);
		contentPane.add(textMaxn);
		textMaxn.setColumns(10);
		
		JLabel label_1 = new JLabel("最小数：");
		label_1.setBounds(340, 63, 60, 15);
		contentPane.add(label_1);
		
		textMins = new JTextField();
		textMins.setBounds(400, 60, 66, 21);
		contentPane.add(textMins);
		textMins.setColumns(10);
		
		JLabel label_2 = new JLabel("运算符选择：");
		label_2.setBounds(10, 100, 100, 15);
		contentPane.add(label_2);
		
		JButton OKbtn = new JButton("生成题目");
		OKbtn.setBounds(10, 171, 126, 37);
		contentPane.add(OKbtn);
		
		JButton answerBtn = new JButton("生成题目答案");
		answerBtn.setBounds(182, 171, 126, 37);
		contentPane.add(answerBtn);
		
		final JCheckBox checkBoxAdd = new JCheckBox("+");
		checkBoxAdd.setBounds(95, 96, 47, 23);
		contentPane.add(checkBoxAdd);
		
		final JCheckBox checkBoxSub = new JCheckBox("-");
		checkBoxSub.setBounds(150, 96, 38, 23);
		contentPane.add(checkBoxSub);
		
		final JCheckBox checkBoxMul = new JCheckBox("*");
		checkBoxMul.setBounds(205, 96, 38, 23);
		contentPane.add(checkBoxMul);
		
		final JCheckBox checkBoxDiv = new JCheckBox("/");
		checkBoxDiv.setBounds(260, 96, 47, 23);
		contentPane.add(checkBoxDiv);
		
		JLabel labelDel = new JLabel("小数：");
		labelDel.setBounds(50, 132, 45, 15);
		contentPane.add(labelDel);
		
		final JCheckBox checkBoxDel = new JCheckBox();
		checkBoxDel.setBounds(90, 128, 47, 23);
		contentPane.add(checkBoxDel);
		
		JLabel label_3 = new JLabel("整数：");
		label_3.setBounds(220, 132, 47, 15);
		contentPane.add(label_3);
		
		final JCheckBox checkBoxInt = new JCheckBox();
		checkBoxInt.setBounds(260, 128, 54, 23);
		contentPane.add(checkBoxInt);
		
		JLabel label_4 = new JLabel("多项式：");
		label_4.setBounds(350, 132, 60, 15);
		contentPane.add(label_4);
		
		final JCheckBox checkBoxPoly = new JCheckBox();
		checkBoxPoly.setBounds(405, 128, 38, 23);
		contentPane.add(checkBoxPoly);
		
		final JTextArea textAreaResult = new JTextArea();
		JScrollPane jsp = new JScrollPane(textAreaResult);
		jsp.setBounds(10, 225, 473, 540);
		jsp.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		contentPane.add(jsp);
		
		JButton buttonSave = new JButton("保存");
		buttonSave.setBounds(355, 171, 126, 37);
		contentPane.add(buttonSave);
		this.setVisible(true);
		
		//得到答案
		answerBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String str = QG.printAnswer();
				textAreaResult.setText(str);
			}
		});	
		
		//获取输出文件
		buttonSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BufferedWriter bw;
				try {
					bw = new BufferedWriter(
							new OutputStreamWriter(
								new BufferedOutputStream(	
									new FileOutputStream(new File("D:/test/ArithmeticGenerator.txt")))));
				
					ArrayList<String> list = new ArrayList<String>();
					list = QG.getAnswer();
					for (String str : list){
						bw.write(str);
						bw.newLine();
					}
					bw.flush();
					bw.close();
				} catch (FileNotFoundException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
			}
		});	
		
		/**
		 * 生成题目点击事件
		 */
		OKbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean integer = false;
				boolean decimal = false;
				boolean polynomial = false;
				boolean add = false;
				boolean sub = false;
				boolean mul = false;
				boolean div = false;
				int queNum,maxn,mins;
				if (checkBoxDel.isSelected()) {
					if (decimal == true){
						decimal = false;
					} else {
						decimal = true;
					}
				}
				if (checkBoxInt.isSelected()) {
					if (integer == true){
						integer = false;
					} else {
						integer = true;
					}
				}
				if (checkBoxPoly.isSelected()) {
					if (polynomial == true){
						polynomial = false;
					} else {
						polynomial = true;
					}
				}
				if (checkBoxDiv.isSelected()) {
					if (div == true){
						div = false;
					} else {
						div = true;
					}
				}
				if (checkBoxMul.isSelected()) {
					if (mul == true){
						mul = false;
					} else {
						mul = true;
					}
				}
				if (checkBoxSub.isSelected()) {
					if (sub == true){
						sub = false;
					} else {
						sub = true;
					}
				}
				if (checkBoxAdd.isSelected()){
					if (add == true){
						add = false;
					} else {
						add = true;
					}
				}
				System.out.println(integer+" "+decimal+" "+polynomial+" "+add+" "+sub+" "+mul+" "+div);
				//参数验证
				try {
					quseNum = Integer.parseInt(textNum.getText());
					Maxn = Integer.parseInt(textMaxn.getText());
					Mins = Integer.parseInt(textMins.getText());
					System.out.println(quseNum + " " +Maxn+" "+Mins);
					
				} catch (Exception e2) {
					e2.printStackTrace();
					JOptionPane.showMessageDialog(null, "【题目数量、操作数、最大数格式错误，请重新输入】", "参数格式错误", JOptionPane.ERROR_MESSAGE);
					System.out.println("【题目数量、操作数、最大数格式错误，请重新输入】");
					return;
				}
				if (quseNum>1000||quseNum<=0) {
					JOptionPane.showMessageDialog(null, "题目数量范围1~1000,请重新输入", "题目数量超出范围", JOptionPane.ERROR_MESSAGE);
					System.out.println("题目数量范围1~1000,请重新输入");
					return;
					
				}
				if (Maxn>10000 || Maxn <= Mins) {
					JOptionPane.showMessageDialog(null, "最大值小于最小值", "最大值超出范围", JOptionPane.ERROR_MESSAGE);
					System.out.println("请重新输入");
					return;
					
				}
				if (Mins >= Maxn ||Mins<1) {
					JOptionPane.showMessageDialog(null, "最小值大于最大值", "最小值超出范围", JOptionPane.ERROR_MESSAGE);
					System.out.println("请重新输入");
					return;
					
				}
				GetOperator Go = new GetOperator(add,sub,mul,div);
				QG = new QusetionGenerator(Maxn,Mins,quseNum,integer,decimal,polynomial,Go);
				QG.startGenerator(); 
				String result = QG.printQusetion();
				textAreaResult.setText(result);
			}
		});	
	}
}