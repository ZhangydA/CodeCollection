package windowsDesign;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.UIManager;

import org.jvnet.substance.SubstanceLookAndFeel;

public class SubstanceTools {
    public static void useSkin() throws Exception {  
        JFrame.setDefaultLookAndFeelDecorated(true);  
        JDialog.setDefaultLookAndFeelDecorated(true);  
  
        UIManager  
                .setLookAndFeel("org.jvnet.substance.skin.SubstanceBusinessBlackSteelLookAndFeel");  
    }  
  
    public static void useTheme() throws Exception {  
        java.awt.EventQueue.invokeLater(new Runnable() {  
            public void run() {  
                // 此处设置皮肤和主题  
                SubstanceLookAndFeel  
                        .setCurrentTheme("org.jvnet.substance.theme.SubstanceDarkVioletTheme.class");  
            }  
        });  
    }

}
