package cn.sau.PairProgramming.com;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ArithmeticGeneratorAutoTest {
    @Test
    public void testStartGenerator(){
    	assertEquals("+", new GetOperator(true,false,false,false).GetRuler());
    	assertEquals("-", new GetOperator(false,true,false,false).GetRuler());
    	assertEquals("*", new GetOperator(false,false,true,false).GetRuler());
    	assertEquals("/", new GetOperator(false,false,false,true).GetRuler());
    	assertEquals("+-", new GetOperator(true,true,false,false).GetRuler());
    	assertEquals("+*", new GetOperator(true,false,true,false).GetRuler());
    	assertEquals("+/", new GetOperator(true,false,false,true).GetRuler());
    	assertEquals("-*", new GetOperator(false,true,true,false).GetRuler());
    	assertEquals("-/", new GetOperator(false,true,false,true).GetRuler());
    	assertEquals("*/", new GetOperator(false,false,true,true).GetRuler());
    	assertEquals("+-*", new GetOperator(true,true,true,false).GetRuler());
    	assertEquals("+-/", new GetOperator(true,true,false,true).GetRuler());
    	assertEquals("+*/", new GetOperator(true,false,true,true).GetRuler());
    	assertEquals("-*/", new GetOperator(false,true,true,true).GetRuler());
    	assertEquals("+-*/", new GetOperator(true,true,true,true).GetRuler());
    }
    @Test
    public void testQusetionGenerator(){
    	assertEquals(true,new QusetionGenerator().getIntegerQuestion());
    	assertEquals(true,new QusetionGenerator().getDoubleQuestion());
    	assertEquals(true,new QusetionGenerator().getIntegerPolynomialQusetion());
    	assertEquals(true,new QusetionGenerator().getDoublePolynomialQusetion());
    	
    	assertEquals(true,new QusetionGenerator(true,false,false).startGenerator());
    	assertEquals(true,new QusetionGenerator(true,false,true).startGenerator());
    	assertEquals(true,new QusetionGenerator(false,true,false).startGenerator());
    	assertEquals(true,new QusetionGenerator(false,true,true).startGenerator());
    	assertEquals(false,new QusetionGenerator(true,true,false).startGenerator());
    	assertEquals(false,new QusetionGenerator(true,true,true).startGenerator());
    }
    
}
